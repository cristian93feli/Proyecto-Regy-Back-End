package com.regyinventory.service.implementation;

import com.regyinventory.dto.request.ActualizarUbicacionRequestDTO;
import com.regyinventory.dto.request.CrearUbicacionRequestDTO;
import com.regyinventory.dto.response.PageResponseDTO;
import com.regyinventory.dto.response.UbicacionResponseDTO;
import com.regyinventory.entities.Ubicacion;
import com.regyinventory.entities.Usuario;
import com.regyinventory.enums.TipoAccionLog;
import com.regyinventory.enums.TipoUbicacion;
import com.regyinventory.exceptions.BusinessException;
import com.regyinventory.exceptions.ResourceNotFoundException;
import com.regyinventory.repository.ILoteInventarioRepository;
import com.regyinventory.repository.IUbicacionRepository;
import com.regyinventory.repository.IUsuarioRepository;
import com.regyinventory.service.contracts.IUbicacionService;
import com.regyinventory.utils.PageableUtil;

import java.util.List;

import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Service
@RequiredArgsConstructor
@Transactional(readOnly = true)
public class UbicacionService implements IUbicacionService {

    private final IUbicacionRepository ubicacionRepository;
    private final IUsuarioRepository usuarioRepository;
    private final ILoteInventarioRepository loteInventarioRepository;
    private final OperacionSupport operacionSupport;

    @Override
    @Transactional
    public UbicacionResponseDTO crear(CrearUbicacionRequestDTO solicitud) {
        String codigoNormalizado = normalizarCodigo(solicitud.getCodigo());
        validarCodigoDisponible(codigoNormalizado, null);

        Ubicacion ubicacionPadre = resolverYValidarPadre(solicitud.getTipo(), solicitud.getUbicacionPadreId());
        Usuario usuarioAsignado = resolverUsuarioAsignado(solicitud.getTipo(), solicitud.getUsuarioAsignadoId());

        Ubicacion nuevaUbicacion = Ubicacion.builder()
                .codigo(codigoNormalizado)
                .nombre(solicitud.getNombre().trim())
                .descripcion(limpiarTextoOpcional(solicitud.getDescripcion()))
                .tipo(solicitud.getTipo())
                .ubicacionPadre(ubicacionPadre)
                .usuarioAsignado(usuarioAsignado)
                .build();

        Ubicacion ubicacionCreada = ubicacionRepository.save(nuevaUbicacion);
        operacionSupport.log(TipoAccionLog.CREAR, "Ubicacion", ubicacionCreada.getId(), "Ubicación creada");
        return convertirRespuesta(ubicacionCreada);
    }

    @Override
    @Transactional
    public UbicacionResponseDTO actualizar(Long ubicacionId, ActualizarUbicacionRequestDTO solicitud) {
        Ubicacion ubicacionExistente = obtenerUbicacion(ubicacionId);
        String codigoNormalizado = normalizarCodigo(solicitud.getCodigo());
        validarCodigoDisponible(codigoNormalizado, ubicacionId);

        ubicacionExistente.setCodigo(codigoNormalizado);
        ubicacionExistente.setNombre(solicitud.getNombre().trim());
        ubicacionExistente.setDescripcion(limpiarTextoOpcional(solicitud.getDescripcion()));
        ubicacionExistente.setUsuarioAsignado(
                resolverUsuarioAsignado(ubicacionExistente.getTipo(), solicitud.getUsuarioAsignadoId())
        );

        return convertirRespuesta(ubicacionRepository.save(ubicacionExistente));
    }

    @Override
    public UbicacionResponseDTO buscar(Long ubicacionId) {
        return convertirRespuesta(obtenerUbicacion(ubicacionId));
    }

    @Override
    public PageResponseDTO<UbicacionResponseDTO> listar(
            Integer pagina,
            Integer tamano,
            String ordenarPor,
            String direccion
    ) {
        return PageResponseDTO.fromPage(
                ubicacionRepository.findAll(PageableUtil.create(pagina, tamano, ordenarPor, direccion)),
                this::convertirRespuesta
        );
    }

    @Override
    public List<UbicacionResponseDTO> listarPorTipo(TipoUbicacion tipoUbicacion) {
        return ubicacionRepository.findByTipo(tipoUbicacion).stream().map(this::convertirRespuesta).toList();
    }

    @Override
    public List<UbicacionResponseDTO> listarHijas(Long ubicacionPadreId) {
        obtenerUbicacion(ubicacionPadreId);
        return ubicacionRepository.findByUbicacionPadreId(ubicacionPadreId).stream()
                .map(this::convertirRespuesta)
                .toList();
    }

    @Override
    @Transactional
    public UbicacionResponseDTO cambiarEstado(Long ubicacionId, boolean activo) {
        Ubicacion ubicacion = obtenerUbicacion(ubicacionId);
        if (!activo && ubicacionRepository.existsByUbicacionPadreId(ubicacionId)) {
            throw new BusinessException("No se puede desactivar una ubicación que tiene ubicaciones hijas");
        }
        if (!activo && loteInventarioRepository.existsByUbicacionIdAndCantidadGreaterThan(ubicacionId, 0)) {
            throw new BusinessException("No se puede desactivar una ubicación que contiene stock");
        }
        ubicacion.setActivo(activo);
        return convertirRespuesta(ubicacionRepository.save(ubicacion));
    }

    @Override
    @Transactional
    public void eliminar(Long ubicacionId) {
        Ubicacion ubicacion = obtenerUbicacion(ubicacionId);
        if (ubicacionRepository.existsByUbicacionPadreId(ubicacionId)) {
            throw new BusinessException("No se puede eliminar una ubicación que tiene ubicaciones hijas");
        }
        if (loteInventarioRepository.existsByUbicacionIdAndCantidadGreaterThan(ubicacionId, 0)) {
            throw new BusinessException("No se puede eliminar una ubicación que contiene stock");
        }
        ubicacionRepository.delete(ubicacion);
    }

    private Ubicacion resolverYValidarPadre(TipoUbicacion tipoUbicacion, Long ubicacionPadreId) {
        if (tipoUbicacion == TipoUbicacion.DEPOSITO || tipoUbicacion == TipoUbicacion.ZONA_EMPAQUE) {
            if (ubicacionPadreId != null) {
                throw new BusinessException("Los depósitos y zonas de empaque no pueden tener ubicación padre");
            }
            return null;
        }
        if (ubicacionPadreId == null) {
            throw new BusinessException("El estante o la caja deben tener una ubicación padre");
        }
        Ubicacion ubicacionPadre = obtenerUbicacionActiva(ubicacionPadreId);
        if (tipoUbicacion == TipoUbicacion.ESTANTE && ubicacionPadre.getTipo() != TipoUbicacion.DEPOSITO) {
            throw new BusinessException("Un estante únicamente puede pertenecer a un depósito");
        }
        if (tipoUbicacion == TipoUbicacion.CAJA && ubicacionPadre.getTipo() != TipoUbicacion.ESTANTE) {
            throw new BusinessException("Una caja únicamente puede pertenecer a un estante");
        }
        return ubicacionPadre;
    }

    private Usuario resolverUsuarioAsignado(TipoUbicacion tipoUbicacion, Long usuarioAsignadoId) {
        if (tipoUbicacion != TipoUbicacion.ZONA_EMPAQUE) {
            if (usuarioAsignadoId != null) {
                throw new BusinessException("Solo una zona de empaque puede tener un usuario asignado");
            }
            return null;
        }
        if (usuarioAsignadoId == null) {
            return null;
        }
        Usuario usuarioAsignado = usuarioRepository.findById(usuarioAsignadoId)
                .orElseThrow(() -> new ResourceNotFoundException("Usuario asignado no encontrado"));
        if (!usuarioAsignado.getActivo()) {
            throw new BusinessException("El usuario asignado está inactivo");
        }
        return usuarioAsignado;
    }

    private void validarCodigoDisponible(String codigo, Long ubicacionIdExcluida) {
        boolean codigoExiste = ubicacionIdExcluida == null
                ? ubicacionRepository.existsByCodigoIgnoreCase(codigo)
                : ubicacionRepository.existsByCodigoIgnoreCaseAndIdNot(codigo, ubicacionIdExcluida);
        if (codigoExiste) {
            throw new BusinessException("Ya existe una ubicación con el código indicado");
        }
    }

    private Ubicacion obtenerUbicacion(Long ubicacionId) {
        return ubicacionRepository.findById(ubicacionId)
                .orElseThrow(() -> new ResourceNotFoundException("Ubicación no encontrada"));
    }

    private Ubicacion obtenerUbicacionActiva(Long ubicacionId) {
        Ubicacion ubicacion = obtenerUbicacion(ubicacionId);
        if (!ubicacion.getActivo()) {
            throw new BusinessException("La ubicación está inactiva");
        }
        return ubicacion;
    }

    private UbicacionResponseDTO convertirRespuesta(Ubicacion ubicacion) {
        Ubicacion deposito = obtenerDepositoRaiz(ubicacion);
        return UbicacionResponseDTO.builder()
                .id(ubicacion.getId())
                .codigo(ubicacion.getCodigo())
                .nombre(ubicacion.getNombre())
                .descripcion(ubicacion.getDescripcion())
                .tipo(ubicacion.getTipo())
                .ubicacionPadreId(ubicacion.getUbicacionPadre() == null ? null : ubicacion.getUbicacionPadre().getId())
                .ubicacionPadreNombre(ubicacion.getUbicacionPadre() == null ? null : ubicacion.getUbicacionPadre().getNombre())
                .depositoId(deposito == null ? null : deposito.getId())
                .depositoNombre(deposito == null ? null : deposito.getNombre())
                .usuarioAsignadoId(ubicacion.getUsuarioAsignado() == null ? null : ubicacion.getUsuarioAsignado().getId())
                .usuarioAsignadoNombre(ubicacion.getUsuarioAsignado() == null ? null : ubicacion.getUsuarioAsignado().getUsername())
                .admiteInventario(admiteInventario(ubicacion))
                .activo(ubicacion.getActivo())
                .build();
    }

    private Ubicacion obtenerDepositoRaiz(Ubicacion ubicacion) {
        Ubicacion ubicacionActual = ubicacion;
        while (ubicacionActual != null && ubicacionActual.getTipo() != TipoUbicacion.DEPOSITO) {
            ubicacionActual = ubicacionActual.getUbicacionPadre();
        }
        return ubicacionActual;
    }

    private boolean admiteInventario(Ubicacion ubicacion) {
        return ubicacion.getTipo() == TipoUbicacion.CAJA || ubicacion.getTipo() == TipoUbicacion.ZONA_EMPAQUE;
    }

    private String normalizarCodigo(String codigo) {
        return codigo.trim().toUpperCase();
    }

    private String limpiarTextoOpcional(String texto) {
        return texto == null || texto.isBlank() ? null : texto.trim();
    }
}
