package com.regyinventory.service.implementation;

import com.regyinventory.dto.request.CompletarSolicitudRequestDTO;
import com.regyinventory.dto.request.CrearSolicitudRequestDTO;
import com.regyinventory.dto.response.PageResponseDTO;
import com.regyinventory.dto.response.SolicitudResponseDTO;
import com.regyinventory.entities.LoteInventario;
import com.regyinventory.entities.MovimientoInventario;
import com.regyinventory.entities.Producto;
import com.regyinventory.entities.SolicitudReposicion;
import com.regyinventory.entities.Ubicacion;
import com.regyinventory.enums.EstadoSolicitud;
import com.regyinventory.enums.TipoAccionLog;
import com.regyinventory.enums.TipoMovimiento;
import com.regyinventory.enums.TipoUbicacion;
import com.regyinventory.exceptions.BusinessException;
import com.regyinventory.exceptions.ResourceNotFoundException;
import com.regyinventory.repository.ILoteInventarioRepository;
import com.regyinventory.repository.IMovimientoInventarioRepository;
import com.regyinventory.repository.IProductoRepository;
import com.regyinventory.repository.ISolicitudReposicionRepository;
import com.regyinventory.repository.IUbicacionRepository;
import com.regyinventory.service.contracts.ISolicitudReposicionService;

import java.time.LocalDate;
import java.util.Comparator;
import java.util.List;

import lombok.RequiredArgsConstructor;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Service
@RequiredArgsConstructor
@Transactional(readOnly = true)
public class SolicitudReposicionService implements ISolicitudReposicionService {
    private final ISolicitudReposicionRepository solicitudRepository;
    private final IProductoRepository productoRepository;
    private final IUbicacionRepository ubicacionRepository;
    private final ILoteInventarioRepository loteInventarioRepository;
    private final IMovimientoInventarioRepository movimientoInventarioRepository;
    private final InventarioService inventarioService;
    private final OperacionSupport operacionSupport;

    @Override
    @Transactional
    public SolicitudResponseDTO crear(CrearSolicitudRequestDTO solicitud) {
        Producto producto = productoRepository.findById(solicitud.getProductoId())
                .orElseThrow(() -> new ResourceNotFoundException("Producto no encontrado"));
        Ubicacion zonaDestino = obtenerZonaEmpaqueActiva(solicitud.getZonaDestinoId());
        SolicitudReposicion nuevaSolicitud = SolicitudReposicion.builder()
                .producto(producto)
                .cantidad(solicitud.getCantidad())
                .prioridad(solicitud.getPrioridad())
                .zonaDestino(zonaDestino)
                .usuarioSolicitante(operacionSupport.usuarioActual())
                .observaciones(solicitud.getObservaciones())
                .build();
        SolicitudReposicion solicitudGuardada = solicitudRepository.save(nuevaSolicitud);
        operacionSupport.log(TipoAccionLog.CREAR_SOLICITUD, "SolicitudReposicion", solicitudGuardada.getId(), "Solicitud creada");
        return convertirRespuesta(solicitudGuardada);
    }

    @Override
    public PageResponseDTO<SolicitudResponseDTO> listar(EstadoSolicitud estado, Integer pagina, Integer tamano) {
        Pageable paginacion = PageRequest.of(pagina, tamano, Sort.by(Sort.Direction.DESC, "fechaCreacion"));
        return PageResponseDTO.fromPage(
                estado == null ? solicitudRepository.findAll(paginacion) : solicitudRepository.findByEstado(estado, paginacion),
                this::convertirRespuesta
        );
    }

    @Override
    @Transactional
    public SolicitudResponseDTO completar(Long solicitudId, CompletarSolicitudRequestDTO solicitudCompletar) {
        SolicitudReposicion solicitudReposicion = obtenerSolicitud(solicitudId);
        if (solicitudReposicion.getEstado() != EstadoSolicitud.PENDIENTE) {
            throw new BusinessException("La solicitud no está pendiente");
        }
        List<LoteInventario> lotesEnCajas = loteInventarioRepository.findAllByCantidadGreaterThan(0).stream()
                .filter(loteInventario -> loteInventario.getProducto().getId().equals(solicitudReposicion.getProducto().getId()))
                .filter(loteInventario -> loteInventario.getUbicacion().getTipo() == TipoUbicacion.CAJA)
                .sorted(Comparator.comparing(
                        (LoteInventario loteInventario) -> loteInventario.getFechaVencimiento() == null
                                ? LocalDate.MAX
                                : loteInventario.getFechaVencimiento()
                ).thenComparing(LoteInventario::getFechaIngreso))
                .toList();
        int cantidadDisponible = lotesEnCajas.stream().mapToInt(LoteInventario::getCantidad).sum();
        if (cantidadDisponible < solicitudReposicion.getCantidad()) {
            throw new BusinessException("Stock insuficiente en las cajas de los depósitos");
        }

        int cantidadPendiente = solicitudReposicion.getCantidad();
        for (LoteInventario loteOrigen : lotesEnCajas) {
            if (cantidadPendiente == 0) {
                break;
            }
            int cantidadTransferida = Math.min(cantidadPendiente, loteOrigen.getCantidad());
            inventarioService.transferirLotes(
                    solicitudReposicion.getProducto(),
                    cantidadTransferida,
                    loteOrigen.getUbicacion(),
                    solicitudReposicion.getZonaDestino()
            );
            MovimientoInventario movimientoReposicion = MovimientoInventario.builder()
                    .producto(solicitudReposicion.getProducto())
                    .cantidad(cantidadTransferida)
                    .tipoMovimiento(TipoMovimiento.REPOSICION)
                    .ubicacionOrigen(loteOrigen.getUbicacion())
                    .ubicacionDestino(solicitudReposicion.getZonaDestino())
                    .observaciones(solicitudCompletar == null ? null : solicitudCompletar.getObservaciones())
                    .usuario(operacionSupport.usuarioActual())
                    .build();
            movimientoInventarioRepository.save(movimientoReposicion);
            cantidadPendiente -= cantidadTransferida;
        }
        solicitudReposicion.setEstado(EstadoSolicitud.COMPLETADA);
        solicitudReposicion.setUsuarioResponsable(operacionSupport.usuarioActual());
        solicitudRepository.save(solicitudReposicion);
        operacionSupport.log(TipoAccionLog.COMPLETAR_SOLICITUD, "SolicitudReposicion", solicitudId, "Solicitud completada");
        return convertirRespuesta(solicitudReposicion);
    }

    @Override
    @Transactional
    public SolicitudResponseDTO cancelar(Long solicitudId) {
        SolicitudReposicion solicitudReposicion = obtenerSolicitud(solicitudId);
        if (solicitudReposicion.getEstado() != EstadoSolicitud.PENDIENTE) {
            throw new BusinessException("La solicitud no está pendiente");
        }
        solicitudReposicion.setEstado(EstadoSolicitud.CANCELADA);
        solicitudReposicion.setUsuarioResponsable(operacionSupport.usuarioActual());
        solicitudRepository.save(solicitudReposicion);
        operacionSupport.log(TipoAccionLog.CANCELAR_SOLICITUD, "SolicitudReposicion", solicitudId, "Solicitud cancelada");
        return convertirRespuesta(solicitudReposicion);
    }

    private SolicitudReposicion obtenerSolicitud(Long solicitudId) {
        return solicitudRepository.findById(solicitudId)
                .orElseThrow(() -> new ResourceNotFoundException("Solicitud no encontrada"));
    }

    private Ubicacion obtenerZonaEmpaqueActiva(Long zonaEmpaqueId) {
        Ubicacion zonaEmpaque = ubicacionRepository.findById(zonaEmpaqueId)
                .orElseThrow(() -> new ResourceNotFoundException("Zona de empaque no encontrada"));
        if (!zonaEmpaque.getActivo() || zonaEmpaque.getTipo() != TipoUbicacion.ZONA_EMPAQUE) {
            throw new BusinessException("La ubicación destino debe ser una zona de empaque activa");
        }
        return zonaEmpaque;
    }

    private SolicitudResponseDTO convertirRespuesta(SolicitudReposicion solicitudReposicion) {
        return SolicitudResponseDTO.builder()
                .id(solicitudReposicion.getId())
                .productoId(solicitudReposicion.getProducto().getId())
                .productoNombre(solicitudReposicion.getProducto().getNombre())
                .cantidad(solicitudReposicion.getCantidad())
                .prioridad(solicitudReposicion.getPrioridad())
                .estado(solicitudReposicion.getEstado())
                .zonaDestinoId(solicitudReposicion.getZonaDestino().getId())
                .zonaDestinoNombre(solicitudReposicion.getZonaDestino().getNombre())
                .usuarioSolicitante(solicitudReposicion.getUsuarioSolicitante().getUsername())
                .usuarioResponsable(
                        solicitudReposicion.getUsuarioResponsable() == null
                                ? null
                                : solicitudReposicion.getUsuarioResponsable().getUsername()
                )
                .observaciones(solicitudReposicion.getObservaciones())
                .fechaCreacion(solicitudReposicion.getFechaCreacion())
                .build();
    }
}
