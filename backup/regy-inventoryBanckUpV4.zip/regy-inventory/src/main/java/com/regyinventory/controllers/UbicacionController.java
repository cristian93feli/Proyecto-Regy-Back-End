package com.regyinventory.controllers;

import com.regyinventory.dto.request.ActualizarUbicacionRequestDTO;
import com.regyinventory.dto.request.CrearUbicacionRequestDTO;
import com.regyinventory.dto.response.ApiResponse;
import com.regyinventory.dto.response.PageResponseDTO;
import com.regyinventory.dto.response.UbicacionResponseDTO;
import com.regyinventory.enums.TipoUbicacion;
import com.regyinventory.service.contracts.IUbicacionService;
import com.regyinventory.utils.constants.swagger.DocumentacionApi;
import com.regyinventory.utils.constants.security.ExpresionesSeguridad;
import com.regyinventory.utils.constants.mensajes.MensajesExito;
import com.regyinventory.utils.constants.api.RutasApi;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;

import java.util.List;

import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PatchMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping(RutasApi.UBICACIONES)
@RequiredArgsConstructor
@Tag(
        name = "Ubicaciones físicas",
        description = "Administración de depósitos, estantes, cajas y zonas de empaque"
)
public class UbicacionController {

    private final IUbicacionService ubicacionService;

    @PostMapping
    @PreAuthorize(ExpresionesSeguridad.UBICACION_CREAR)
    @Operation(
            summary = "Crear una ubicación",
            description = "Crea un depósito, estante, caja o zona de empaque respetando la jerarquía permitida."
    )
    public ResponseEntity<ApiResponse<UbicacionResponseDTO>> crear(
            @Valid @RequestBody CrearUbicacionRequestDTO solicitud
    ) {
        return ResponseEntity.status(HttpStatus.CREATED)
                .body(ApiResponse.success(MensajesExito.Ubicacion.CREADA, ubicacionService.crear(solicitud)));
    }

    @GetMapping("/{ubicacionId}")
    @PreAuthorize(ExpresionesSeguridad.UBICACION_CONSULTAR)
    @Operation(summary = "Consultar una ubicación", description = "Obtiene el detalle y la jerarquía de una ubicación.")
    public ApiResponse<UbicacionResponseDTO> buscar(@PathVariable Long ubicacionId) {
        return ApiResponse.success(MensajesExito.Ubicacion.ENCONTRADA, ubicacionService.buscar(ubicacionId));
    }

    @GetMapping
    @PreAuthorize(ExpresionesSeguridad.UBICACION_CONSULTAR)
    @Operation(summary = "Listar ubicaciones", description = "Lista todas las ubicaciones con paginación y ordenamiento.")
    public ApiResponse<PageResponseDTO<UbicacionResponseDTO>> listar(
            @RequestParam(defaultValue = "0") Integer page,
            @RequestParam(defaultValue = "10") Integer size,
            @RequestParam(defaultValue = "id") String sortBy,
            @RequestParam(defaultValue = "ASC") String direction
    ) {
        return ApiResponse.success(
                MensajesExito.Ubicacion.LISTADAS,
                ubicacionService.listar(page, size, sortBy, direction)
        );
    }

    @GetMapping("/tipo/{tipoUbicacion}")
    @PreAuthorize(ExpresionesSeguridad.UBICACION_CONSULTAR)
    @Operation(summary = "Listar por tipo", description = "Lista depósitos, estantes, cajas o zonas de empaque.")
    public ApiResponse<List<UbicacionResponseDTO>> listarPorTipo(@PathVariable TipoUbicacion tipoUbicacion) {
        return ApiResponse.success(MensajesExito.Ubicacion.LISTADAS, ubicacionService.listarPorTipo(tipoUbicacion));
    }

    @GetMapping("/{ubicacionPadreId}/hijas")
    @PreAuthorize(ExpresionesSeguridad.UBICACION_CONSULTAR)
    @Operation(summary = "Listar ubicaciones hijas", description = "Obtiene los estantes de un depósito o las cajas de un estante.")
    public ApiResponse<List<UbicacionResponseDTO>> listarHijas(@PathVariable Long ubicacionPadreId) {
        return ApiResponse.success(MensajesExito.Ubicacion.HIJAS_LISTADAS, ubicacionService.listarHijas(ubicacionPadreId));
    }

    @PutMapping("/{ubicacionId}")
    @PreAuthorize(ExpresionesSeguridad.UBICACION_ACTUALIZAR)
    @Operation(summary = "Actualizar una ubicación", description = "Actualiza datos descriptivos sin cambiar el tipo ni la jerarquía.")
    public ApiResponse<UbicacionResponseDTO> actualizar(
            @PathVariable Long ubicacionId,
            @Valid @RequestBody ActualizarUbicacionRequestDTO solicitud
    ) {
        return ApiResponse.success(MensajesExito.Ubicacion.ACTUALIZADA, ubicacionService.actualizar(ubicacionId, solicitud));
    }

    @PatchMapping("/{ubicacionId}/activar")
    @PreAuthorize(ExpresionesSeguridad.UBICACION_ACTUALIZAR)
    @Operation(summary = "Activar una ubicación")
    public ApiResponse<UbicacionResponseDTO> activar(@PathVariable Long ubicacionId) {
        return ApiResponse.success(MensajesExito.Ubicacion.ACTIVADA, ubicacionService.cambiarEstado(ubicacionId, true));
    }

    @PatchMapping("/{ubicacionId}/desactivar")
    @PreAuthorize(ExpresionesSeguridad.UBICACION_ACTUALIZAR)
    @Operation(summary = "Desactivar una ubicación", description = "No permite desactivar ubicaciones con hijos o stock.")
    public ApiResponse<UbicacionResponseDTO> desactivar(@PathVariable Long ubicacionId) {
        return ApiResponse.success(MensajesExito.Ubicacion.DESACTIVADA, ubicacionService.cambiarEstado(ubicacionId, false));
    }

    @DeleteMapping("/{ubicacionId}")
    @PreAuthorize(ExpresionesSeguridad.UBICACION_ELIMINAR)
    @Operation(summary = "Eliminar una ubicación", description = "Solo elimina ubicaciones sin hijos y sin existencias.")
    public ApiResponse<Void> eliminar(@PathVariable Long ubicacionId) {
        ubicacionService.eliminar(ubicacionId);
        return ApiResponse.success(MensajesExito.Ubicacion.ELIMINADA);
    }
}
