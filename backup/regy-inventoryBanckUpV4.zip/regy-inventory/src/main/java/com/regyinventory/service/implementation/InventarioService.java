package com.regyinventory.service.implementation;

import com.regyinventory.dto.request.IngresoStockRequestDTO;
import com.regyinventory.dto.request.MoverStockRequestDTO;
import com.regyinventory.dto.response.IngresoStockResponseDTO;
import com.regyinventory.dto.response.InventarioResponseDTO;
import com.regyinventory.dto.response.MovimientoResponseDTO;
import com.regyinventory.entities.IngresoStock;
import com.regyinventory.entities.LoteInventario;
import com.regyinventory.entities.MovimientoInventario;
import com.regyinventory.entities.Producto;
import com.regyinventory.entities.Ubicacion;
import com.regyinventory.enums.TipoAccionLog;
import com.regyinventory.enums.TipoMovimiento;
import com.regyinventory.enums.TipoUbicacion;
import com.regyinventory.exceptions.BusinessException;
import com.regyinventory.exceptions.ResourceNotFoundException;
import com.regyinventory.repository.IIngresoStockRepository;
import com.regyinventory.repository.ILoteInventarioRepository;
import com.regyinventory.repository.IMovimientoInventarioRepository;
import com.regyinventory.repository.IProductoRepository;
import com.regyinventory.repository.IUbicacionRepository;
import com.regyinventory.service.contracts.IInventarioService;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Service
@RequiredArgsConstructor
@Transactional(readOnly = true)
public class InventarioService implements IInventarioService {

    private final IProductoRepository productoRepository;
    private final IUbicacionRepository ubicacionRepository;
    private final IIngresoStockRepository ingresoStockRepository;
    private final ILoteInventarioRepository loteInventarioRepository;
    private final IMovimientoInventarioRepository movimientoInventarioRepository;
    private final OperacionSupport operacionSupport;

    @Override
    @Transactional
    public IngresoStockResponseDTO ingresar(IngresoStockRequestDTO solicitud) {
        Producto producto = obtenerProductoActivo(solicitud.getProductoId());
        Ubicacion cajaDestino = obtenerUbicacionActivaQueAdmiteInventario(solicitud.getUbicacionDestinoId());
        if (cajaDestino.getTipo() != TipoUbicacion.CAJA) {
            throw new BusinessException("Los ingresos de mercancía deben registrarse en una caja");
        }

        IngresoStock ingresoStock = IngresoStock.builder()
                .producto(producto)
                .cantidad(solicitud.getCantidad())
                .ubicacion(cajaDestino)
                .fechaVencimiento(solicitud.getFechaVencimiento())
                .observaciones(limpiarTextoOpcional(solicitud.getObservaciones()))
                .usuario(operacionSupport.usuarioActual())
                .build();
        IngresoStock ingresoGuardado = ingresoStockRepository.save(ingresoStock);

        LoteInventario loteIngresado = LoteInventario.builder()
                .producto(producto)
                .ubicacion(cajaDestino)
                .cantidad(solicitud.getCantidad())
                .fechaIngreso(LocalDateTime.now())
                .fechaVencimiento(solicitud.getFechaVencimiento())
                .ingresoStock(ingresoGuardado)
                .build();
        loteInventarioRepository.save(loteIngresado);

        operacionSupport.log(
                TipoAccionLog.INGRESAR_STOCK,
                "IngresoStock",
                ingresoGuardado.getId(),
                "Ingreso de stock registrado"
        );
        return convertirIngresoRespuesta(ingresoGuardado);
    }

    @Override
    @Transactional
    public MovimientoResponseDTO mover(MoverStockRequestDTO solicitud) {
        if (solicitud.getUbicacionOrigenId().equals(solicitud.getUbicacionDestinoId())) {
            throw new BusinessException("El origen y el destino no pueden ser iguales");
        }
        Producto producto = obtenerProductoActivo(solicitud.getProductoId());
        Ubicacion ubicacionOrigen = obtenerUbicacionActivaQueAdmiteInventario(solicitud.getUbicacionOrigenId());
        Ubicacion ubicacionDestino = obtenerUbicacionActivaQueAdmiteInventario(solicitud.getUbicacionDestinoId());

        transferirLotes(producto, solicitud.getCantidad(), ubicacionOrigen, ubicacionDestino);

        MovimientoInventario movimientoInventario = MovimientoInventario.builder()
                .producto(producto)
                .cantidad(solicitud.getCantidad())
                .tipoMovimiento(TipoMovimiento.TRASLADO)
                .ubicacionOrigen(ubicacionOrigen)
                .ubicacionDestino(ubicacionDestino)
                .observaciones(limpiarTextoOpcional(solicitud.getObservaciones()))
                .usuario(operacionSupport.usuarioActual())
                .build();
        MovimientoInventario movimientoGuardado = movimientoInventarioRepository.save(movimientoInventario);

        operacionSupport.log(
                TipoAccionLog.MOVER_STOCK,
                "MovimientoInventario",
                movimientoGuardado.getId(),
                "Movimiento de stock registrado"
        );
        return convertirMovimientoRespuesta(movimientoGuardado);
    }

    public void transferirLotes(
            Producto producto,
            int cantidadSolicitada,
            Ubicacion ubicacionOrigen,
            Ubicacion ubicacionDestino
    ) {
        List<LoteInventario> lotesDisponibles = loteInventarioRepository.buscarLotesParaActualizar(
                producto.getId(),
                ubicacionOrigen.getId()
        );
        ordenarLotesFefoFifo(lotesDisponibles);

        int cantidadDisponible = lotesDisponibles.stream().mapToInt(LoteInventario::getCantidad).sum();
        if (cantidadDisponible < cantidadSolicitada) {
            throw new BusinessException("Stock insuficiente. Disponible: " + cantidadDisponible);
        }

        int cantidadPendiente = cantidadSolicitada;
        for (LoteInventario loteDisponible : lotesDisponibles) {
            if (cantidadPendiente == 0) {
                break;
            }
            int cantidadTransferida = Math.min(cantidadPendiente, loteDisponible.getCantidad());
            loteDisponible.setCantidad(loteDisponible.getCantidad() - cantidadTransferida);
            loteInventarioRepository.save(loteDisponible);

            LoteInventario loteDestino = LoteInventario.builder()
                    .producto(producto)
                    .ubicacion(ubicacionDestino)
                    .cantidad(cantidadTransferida)
                    .fechaIngreso(loteDisponible.getFechaIngreso())
                    .fechaVencimiento(loteDisponible.getFechaVencimiento())
                    .ingresoStock(loteDisponible.getIngresoStock())
                    .build();
            loteInventarioRepository.save(loteDestino);
            cantidadPendiente -= cantidadTransferida;
        }
    }

    @Override
    public List<InventarioResponseDTO> existencias() {
        Map<String, InventarioResponseDTO> existenciasAgrupadas = new LinkedHashMap<>();
        for (LoteInventario loteInventario : loteInventarioRepository.findAllByCantidadGreaterThan(0)) {
            String claveAgrupacion = loteInventario.getProducto().getId() + "-" + loteInventario.getUbicacion().getId();
            InventarioResponseDTO existencia = existenciasAgrupadas.computeIfAbsent(
                    claveAgrupacion,
                    clave -> construirExistenciaInicial(loteInventario)
            );
            existencia.setCantidad(existencia.getCantidad() + loteInventario.getCantidad());
            existencia.setStockBajo(existencia.getCantidad() <= existencia.getStockMinimo());
        }
        return new ArrayList<>(existenciasAgrupadas.values());
    }

    @Override
    public List<InventarioResponseDTO> stockBajo() {
        return existencias().stream().filter(InventarioResponseDTO::getStockBajo).toList();
    }

    public Ubicacion obtenerUbicacionActivaQueAdmiteInventario(Long ubicacionId) {
        Ubicacion ubicacion = ubicacionRepository.findById(ubicacionId)
                .orElseThrow(() -> new ResourceNotFoundException("Ubicación no encontrada"));
        if (!ubicacion.getActivo()) {
            throw new BusinessException("La ubicación está inactiva");
        }
        if (ubicacion.getTipo() != TipoUbicacion.CAJA && ubicacion.getTipo() != TipoUbicacion.ZONA_EMPAQUE) {
            throw new BusinessException("El inventario únicamente puede existir en cajas o zonas de empaque");
        }
        validarCadenaPadresActiva(ubicacion);
        return ubicacion;
    }

    private Producto obtenerProductoActivo(Long productoId) {
        Producto producto = productoRepository.findById(productoId)
                .orElseThrow(() -> new ResourceNotFoundException("Producto no encontrado"));
        if (!producto.getActivo()) {
            throw new BusinessException("El producto está inactivo");
        }
        return producto;
    }

    private void validarCadenaPadresActiva(Ubicacion ubicacion) {
        Ubicacion ubicacionPadre = ubicacion.getUbicacionPadre();
        while (ubicacionPadre != null) {
            if (!ubicacionPadre.getActivo()) {
                throw new BusinessException("La ubicación pertenece a una jerarquía inactiva");
            }
            ubicacionPadre = ubicacionPadre.getUbicacionPadre();
        }
    }

    private void ordenarLotesFefoFifo(List<LoteInventario> lotesDisponibles) {
        lotesDisponibles.sort(
                Comparator.comparing(
                        (LoteInventario loteInventario) -> loteInventario.getFechaVencimiento() == null
                                ? LocalDate.MAX
                                : loteInventario.getFechaVencimiento()
                ).thenComparing(LoteInventario::getFechaIngreso)
        );
    }

    private InventarioResponseDTO construirExistenciaInicial(LoteInventario loteInventario) {
        Ubicacion ubicacion = loteInventario.getUbicacion();
        Ubicacion deposito = encontrarDeposito(ubicacion);
        return InventarioResponseDTO.builder()
                .productoId(loteInventario.getProducto().getId())
                .numeroProducto(loteInventario.getProducto().getNumero())
                .nombreProducto(loteInventario.getProducto().getNombre())
                .ubicacionId(ubicacion.getId())
                .ubicacionNombre(construirRutaUbicacion(ubicacion))
                .tipoUbicacion(ubicacion.getTipo())
                .depositoId(deposito == null ? null : deposito.getId())
                .depositoNombre(deposito == null ? null : deposito.getNombre())
                .cantidad(0)
                .stockMinimo(loteInventario.getProducto().getStockMinimo())
                .stockBajo(false)
                .build();
    }

    private IngresoStockResponseDTO convertirIngresoRespuesta(IngresoStock ingresoStock) {
        return IngresoStockResponseDTO.builder()
                .id(ingresoStock.getId())
                .productoId(ingresoStock.getProducto().getId())
                .productoNombre(ingresoStock.getProducto().getNombre())
                .cantidad(ingresoStock.getCantidad())
                .ubicacionDestinoId(ingresoStock.getUbicacion().getId())
                .ubicacionDestinoNombre(construirRutaUbicacion(ingresoStock.getUbicacion()))
                .tipoUbicacionDestino(ingresoStock.getUbicacion().getTipo())
                .fechaVencimiento(ingresoStock.getFechaVencimiento())
                .observaciones(ingresoStock.getObservaciones())
                .usuario(ingresoStock.getUsuario().getUsername())
                .fechaCreacion(ingresoStock.getFechaCreacion())
                .build();
    }

    private MovimientoResponseDTO convertirMovimientoRespuesta(MovimientoInventario movimientoInventario) {
        return MovimientoResponseDTO.builder()
                .id(movimientoInventario.getId())
                .productoId(movimientoInventario.getProducto().getId())
                .productoNombre(movimientoInventario.getProducto().getNombre())
                .cantidad(movimientoInventario.getCantidad())
                .tipoMovimiento(movimientoInventario.getTipoMovimiento())
                .ubicacionOrigenId(movimientoInventario.getUbicacionOrigen().getId())
                .ubicacionOrigenNombre(construirRutaUbicacion(movimientoInventario.getUbicacionOrigen()))
                .tipoUbicacionOrigen(movimientoInventario.getUbicacionOrigen().getTipo())
                .ubicacionDestinoId(movimientoInventario.getUbicacionDestino().getId())
                .ubicacionDestinoNombre(construirRutaUbicacion(movimientoInventario.getUbicacionDestino()))
                .tipoUbicacionDestino(movimientoInventario.getUbicacionDestino().getTipo())
                .observaciones(movimientoInventario.getObservaciones())
                .usuario(movimientoInventario.getUsuario().getUsername())
                .fechaCreacion(movimientoInventario.getFechaCreacion())
                .build();
    }

    private String construirRutaUbicacion(Ubicacion ubicacion) {
        List<String> nombresUbicacion = new ArrayList<>();
        Ubicacion ubicacionActual = ubicacion;
        while (ubicacionActual != null) {
            nombresUbicacion.add(0, ubicacionActual.getNombre());
            ubicacionActual = ubicacionActual.getUbicacionPadre();
        }
        return String.join(" / ", nombresUbicacion);
    }

    private Ubicacion encontrarDeposito(Ubicacion ubicacion) {
        Ubicacion ubicacionActual = ubicacion;
        while (ubicacionActual != null && ubicacionActual.getTipo() != TipoUbicacion.DEPOSITO) {
            ubicacionActual = ubicacionActual.getUbicacionPadre();
        }
        return ubicacionActual;
    }

    private String limpiarTextoOpcional(String texto) {
        return texto == null || texto.isBlank() ? null : texto.trim();
    }
}
