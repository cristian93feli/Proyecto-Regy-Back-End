package com.regyinventory.service.implementation;

import com.regyinventory.dto.request.ConteoAuditoriaRequestDTO;
import com.regyinventory.dto.request.CrearAuditoriaRequestDTO;
import com.regyinventory.dto.response.AuditoriaResponseDTO;
import com.regyinventory.dto.response.DetalleAuditoriaResponseDTO;
import com.regyinventory.dto.response.PageResponseDTO;
import com.regyinventory.entities.AuditoriaInventario;
import com.regyinventory.entities.DetalleAuditoria;
import com.regyinventory.entities.LoteInventario;
import com.regyinventory.entities.Producto;
import com.regyinventory.entities.Ubicacion;
import com.regyinventory.enums.MotivoAjuste;
import com.regyinventory.enums.TipoAccionLog;
import com.regyinventory.enums.TipoAuditoria;
import com.regyinventory.enums.TipoUbicacion;
import com.regyinventory.exceptions.BusinessException;
import com.regyinventory.exceptions.ResourceNotFoundException;
import com.regyinventory.repository.IAuditoriaInventarioRepository;
import com.regyinventory.repository.ILoteInventarioRepository;
import com.regyinventory.repository.IProductoRepository;
import com.regyinventory.service.contracts.IAuditoriaService;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.Comparator;
import java.util.List;

import lombok.RequiredArgsConstructor;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Service
@RequiredArgsConstructor
@Transactional(readOnly = true)
public class AuditoriaService implements IAuditoriaService {
    private final IAuditoriaInventarioRepository auditoriaRepository;
    private final IProductoRepository productoRepository;
    private final ILoteInventarioRepository loteInventarioRepository;
    private final InventarioService inventarioService;
    private final OperacionSupport operacionSupport;

    @Override
    @Transactional
    public AuditoriaResponseDTO crear(CrearAuditoriaRequestDTO solicitud) {
        validarMotivo(solicitud);
        Ubicacion ubicacionAuditada = inventarioService.obtenerUbicacionActivaQueAdmiteInventario(solicitud.getDestinoId());
        validarTipoAuditoria(solicitud.getTipoAuditoria(), ubicacionAuditada);

        AuditoriaInventario auditoria = AuditoriaInventario.builder()
                .tipoAuditoria(solicitud.getTipoAuditoria())
                .destinoId(ubicacionAuditada.getId())
                .motivo(solicitud.getMotivo())
                .motivoOtro(solicitud.getMotivoOtro())
                .observaciones(solicitud.getObservaciones())
                .usuario(operacionSupport.usuarioActual())
                .build();

        for (ConteoAuditoriaRequestDTO conteo : solicitud.getConteos()) {
            Producto producto = productoRepository.findById(conteo.getProductoId())
                    .orElseThrow(() -> new ResourceNotFoundException("Producto no encontrado"));
            int cantidadSistema = loteInventarioRepository.stockUbicacion(producto.getId(), ubicacionAuditada.getId());
            int diferencia = conteo.getCantidadContada() - cantidadSistema;
            aplicarDiferencia(producto, ubicacionAuditada, diferencia);

            DetalleAuditoria detalleAuditoria = DetalleAuditoria.builder()
                    .auditoria(auditoria)
                    .producto(producto)
                    .cantidadSistema(cantidadSistema)
                    .cantidadContada(conteo.getCantidadContada())
                    .diferencia(diferencia)
                    .build();
            auditoria.getDetalles().add(detalleAuditoria);
        }

        AuditoriaInventario auditoriaGuardada = auditoriaRepository.save(auditoria);
        operacionSupport.log(
                TipoAccionLog.AUDITAR,
                "AuditoriaInventario",
                auditoriaGuardada.getId(),
                "Auditoría realizada en " + ubicacionAuditada.getNombre()
        );
        return convertirRespuesta(auditoriaGuardada, ubicacionAuditada.getNombre());
    }

    @Override
    public PageResponseDTO<AuditoriaResponseDTO> listar(Integer pagina, Integer tamano) {
        return PageResponseDTO.fromPage(
                auditoriaRepository.findAll(PageRequest.of(
                        pagina,
                        tamano,
                        Sort.by(Sort.Direction.DESC, "fechaCreacion")
                )),
                auditoria -> convertirRespuesta(auditoria, null)
        );
    }

    private void validarMotivo(CrearAuditoriaRequestDTO solicitud) {
        if (solicitud.getMotivo() == MotivoAjuste.OTRO
                && (solicitud.getMotivoOtro() == null || solicitud.getMotivoOtro().isBlank())) {
            throw new BusinessException("Debe especificar el motivo cuando selecciona OTRO");
        }
    }

    private void validarTipoAuditoria(TipoAuditoria tipoAuditoria, Ubicacion ubicacion) {
        boolean tipoValido = tipoAuditoria == TipoAuditoria.CAJA
                ? ubicacion.getTipo() == TipoUbicacion.CAJA
                : ubicacion.getTipo() == TipoUbicacion.ZONA_EMPAQUE;
        if (!tipoValido) {
            throw new BusinessException("El tipo de auditoría no coincide con el tipo de ubicación");
        }
    }

    private void aplicarDiferencia(Producto producto, Ubicacion ubicacion, int diferencia) {
        if (diferencia > 0) {
            loteInventarioRepository.save(LoteInventario.builder()
                    .producto(producto)
                    .ubicacion(ubicacion)
                    .cantidad(diferencia)
                    .fechaIngreso(LocalDateTime.now())
                    .build());
            return;
        }
        if (diferencia >= 0) {
            return;
        }

        List<LoteInventario> lotesDisponibles = loteInventarioRepository.buscarLotesParaActualizar(
                producto.getId(),
                ubicacion.getId()
        );
        lotesDisponibles.sort(Comparator.comparing(
                (LoteInventario loteInventario) -> loteInventario.getFechaVencimiento() == null
                        ? LocalDate.MAX
                        : loteInventario.getFechaVencimiento()
        ).thenComparing(LoteInventario::getFechaIngreso));

        int cantidadPendiente = -diferencia;
        for (LoteInventario loteDisponible : lotesDisponibles) {
            int cantidadDescontada = Math.min(cantidadPendiente, loteDisponible.getCantidad());
            loteDisponible.setCantidad(loteDisponible.getCantidad() - cantidadDescontada);
            loteInventarioRepository.save(loteDisponible);
            cantidadPendiente -= cantidadDescontada;
            if (cantidadPendiente == 0) {
                break;
            }
        }
    }

    private AuditoriaResponseDTO convertirRespuesta(AuditoriaInventario auditoria, String destinoNombre) {
        return AuditoriaResponseDTO.builder()
                .id(auditoria.getId())
                .tipoAuditoria(auditoria.getTipoAuditoria())
                .destinoId(auditoria.getDestinoId())
                .destinoNombre(destinoNombre)
                .motivo(auditoria.getMotivo())
                .motivoOtro(auditoria.getMotivoOtro())
                .observaciones(auditoria.getObservaciones())
                .usuario(auditoria.getUsuario().getUsername())
                .fechaCreacion(auditoria.getFechaCreacion())
                .detalles(auditoria.getDetalles().stream()
                        .map(detalle -> DetalleAuditoriaResponseDTO.builder()
                                .productoId(detalle.getProducto().getId())
                                .productoNombre(detalle.getProducto().getNombre())
                                .cantidadSistema(detalle.getCantidadSistema())
                                .cantidadContada(detalle.getCantidadContada())
                                .diferencia(detalle.getDiferencia())
                                .build())
                        .toList())
                .build();
    }
}
