# CHANGELOG - REGY Inventory RC Ubicaciones Jerárquicas

## Cambios principales

- Se unificaron depósito, estante, caja y zona de empaque en la entidad `Ubicacion`.
- Se agregó `TipoUbicacion`: `DEPOSITO`, `ESTANTE`, `CAJA`, `ZONA_EMPAQUE`.
- Jerarquía obligatoria: depósito -> estante -> caja.
- Las zonas de empaque son nodos raíz y no admiten hijos.
- El inventario solo puede existir en cajas o zonas de empaque.
- Los ingresos de mercancía solo se registran en cajas.
- Los movimientos se realizan entre cajas y zonas de empaque.
- Solicitudes de reposición tienen como destino una zona de empaque.
- Auditorías solo se realizan sobre cajas o zonas de empaque.
- Se eliminaron los módulos separados `Deposito` y `ZonaEmpaque` para evitar duplicidad de reglas.
- Se agregaron nombres descriptivos en la lógica nueva de ubicaciones, inventario, solicitudes, auditorías y dashboard.
- Se agregó documentación Swagger al controlador unificado de ubicaciones y esquemas de sus DTO.
- Se aplicó formato de cuatro espacios a los archivos Java compactados.

## Validación pendiente

El entorno de generación no dispone de Maven instalado ni acceso garantizado para descargar dependencias. La compilación final debe ejecutarse localmente con `mvn clean test`.
