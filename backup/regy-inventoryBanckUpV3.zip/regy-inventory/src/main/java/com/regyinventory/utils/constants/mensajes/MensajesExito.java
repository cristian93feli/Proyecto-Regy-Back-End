package com.regyinventory.utils.constants.mensajes;

public final class MensajesExito {

    private MensajesExito() {
    }

    public static final class Autenticacion {

        public static final String LOGIN =
                "Inicio de sesión exitoso";

        private Autenticacion() {
        }
    }

    public static final class Usuario {

        public static final String CREADO =
                "Usuario creado correctamente";

        public static final String ENCONTRADO =
                "Usuario encontrado";

        public static final String LISTADOS =
                "Usuarios consultados correctamente";

        public static final String ACTUALIZADO =
                "Usuario actualizado correctamente";

        public static final String CONTRASENA_ACTUALIZADA =
                "Contraseña actualizada correctamente";

        public static final String ACTIVADO =
                "Usuario activado correctamente";

        public static final String DESACTIVADO =
                "Usuario desactivado correctamente";

        private Usuario() {
        }
    }

    public static final class Rol {

        public static final String ENCONTRADO =
                "Rol encontrado";

        public static final String LISTADOS =
                "Roles consultados correctamente";

        private Rol() {
        }
    }

    public static final class Marca {

        public static final String CREADA =
                "Marca creada correctamente";

        public static final String ENCONTRADA =
                "Marca encontrada";

        public static final String LISTADAS =
                "Marcas consultadas correctamente";

        public static final String ACTUALIZADA =
                "Marca actualizada correctamente";

        public static final String ACTIVADA =
                "Marca activada correctamente";

        public static final String DESACTIVADA =
                "Marca desactivada correctamente";

        public static final String ELIMINADA =
                "Marca eliminada correctamente";

        private Marca() {
        }
    }

    public static final class Categoria {

        public static final String CREADA =
                "Categoría creada correctamente";

        public static final String ENCONTRADA =
                "Categoría encontrada";

        public static final String LISTADAS =
                "Categorías consultadas correctamente";

        public static final String ACTUALIZADA =
                "Categoría actualizada correctamente";

        public static final String ACTIVADA =
                "Categoría activada correctamente";

        public static final String DESACTIVADA =
                "Categoría desactivada correctamente";

        public static final String ELIMINADA =
                "Categoría eliminada correctamente";

        private Categoria() {
        }
    }

    public static final class Producto {

        public static final String CREADO =
                "Producto creado correctamente";

        public static final String ENCONTRADO =
                "Producto encontrado";

        public static final String LISTADOS =
                "Productos consultados correctamente";

        public static final String ACTUALIZADO =
                "Producto actualizado correctamente";

        public static final String ACTIVADO =
                "Producto activado correctamente";

        public static final String DESACTIVADO =
                "Producto desactivado correctamente";

        public static final String ELIMINADO =
                "Producto eliminado correctamente";

        public static final String NOMBRE_ENTIDAD =
                "Producto";

        public static final String LOG_CREADO =
                "Producto creado: %s";

        public static final String LOG_ACTUALIZADO =
                "Producto actualizado";

        public static final String LOG_ACTIVADO =
                "Producto activado";

        public static final String LOG_DESACTIVADO =
                "Producto desactivado";

        public static final String LOG_ELIMINADO =
                "Producto eliminado";

        private Producto() {
        }
    }
}
