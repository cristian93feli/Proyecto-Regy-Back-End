package com.regyinventory.service.contracts;

import com.regyinventory.dto.request.IngresoStockRequestDTO;
import com.regyinventory.dto.request.MoverStockRequestDTO;
import com.regyinventory.dto.response.IngresoStockResponseDTO;
import com.regyinventory.dto.response.InventarioResponseDTO;
import com.regyinventory.dto.response.MovimientoResponseDTO;
import java.util.List;

/** Gestiona ingresos, traslados y consultas de existencias. */
public interface IInventarioService {
    IngresoStockResponseDTO ingresar(IngresoStockRequestDTO solicitud);
    MovimientoResponseDTO mover(MoverStockRequestDTO solicitud);
    List<InventarioResponseDTO> existencias();
    List<InventarioResponseDTO> stockBajo();
}
