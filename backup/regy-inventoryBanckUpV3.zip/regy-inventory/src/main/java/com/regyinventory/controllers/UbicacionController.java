package com.regyinventory.controllers;

import com.regyinventory.dto.request.ActualizarUbicacionRequestDTO;
import com.regyinventory.dto.request.CrearUbicacionRequestDTO;
import com.regyinventory.dto.response.ApiResponse;
import com.regyinventory.dto.response.PageResponseDTO;
import com.regyinventory.dto.response.UbicacionResponseDTO;
import com.regyinventory.enums.TipoUbicacion;
import com.regyinventory.service.contracts.IUbicacionService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;

import java.util.List;

import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PatchMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/api/ubicaciones")
@RequiredArgsConstructor
@Tag(
        name = "Ubicaciones físicas",
        description = "Administración de depósitos, estantes, cajas y zonas de empaque"
)
public class UbicacionController {

    private final IUbicacionService ubicacionService;

    @PostMapping
    @PreAuthorize("hasAuthority('LOCATION_CREATE')")
    @Operation(
            summary = "Crear una ubicación",
            description = "Crea un depósito, estante, caja o zona de empaque respetando la jerarquía permitida."
    )
    public ResponseEntity<ApiResponse<UbicacionResponseDTO>> crear(
            @Valid @RequestBody CrearUbicacionRequestDTO solicitud
    ) {
        return ResponseEntity.status(HttpStatus.CREATED)
                .body(ApiResponse.success("Ubicación creada correctamente", ubicacionService.crear(solicitud)));
    }

    @GetMapping("/{ubicacionId}")
    @PreAuthorize("hasAuthority('LOCATION_READ')")
    @Operation(summary = "Consultar una ubicación", description = "Obtiene el detalle y la jerarquía de una ubicación.")
    public ApiResponse<UbicacionResponseDTO> buscar(@PathVariable Long ubicacionId) {
        return ApiResponse.success("Ubicación consultada correctamente", ubicacionService.buscar(ubicacionId));
    }

    @GetMapping
    @PreAuthorize("hasAuthority('LOCATION_READ')")
    @Operation(summary = "Listar ubicaciones", description = "Lista todas las ubicaciones con paginación y ordenamiento.")
    public ApiResponse<PageResponseDTO<UbicacionResponseDTO>> listar(
            @RequestParam(defaultValue = "0") Integer page,
            @RequestParam(defaultValue = "10") Integer size,
            @RequestParam(defaultValue = "id") String sortBy,
            @RequestParam(defaultValue = "ASC") String direction
    ) {
        return ApiResponse.success(
                "Ubicaciones consultadas correctamente",
                ubicacionService.listar(page, size, sortBy, direction)
        );
    }

    @GetMapping("/tipo/{tipoUbicacion}")
    @PreAuthorize("hasAuthority('LOCATION_READ')")
    @Operation(summary = "Listar por tipo", description = "Lista depósitos, estantes, cajas o zonas de empaque.")
    public ApiResponse<List<UbicacionResponseDTO>> listarPorTipo(@PathVariable TipoUbicacion tipoUbicacion) {
        return ApiResponse.success("Ubicaciones consultadas correctamente", ubicacionService.listarPorTipo(tipoUbicacion));
    }

    @GetMapping("/{ubicacionPadreId}/hijas")
    @PreAuthorize("hasAuthority('LOCATION_READ')")
    @Operation(summary = "Listar ubicaciones hijas", description = "Obtiene los estantes de un depósito o las cajas de un estante.")
    public ApiResponse<List<UbicacionResponseDTO>> listarHijas(@PathVariable Long ubicacionPadreId) {
        return ApiResponse.success("Ubicaciones hijas consultadas correctamente", ubicacionService.listarHijas(ubicacionPadreId));
    }

    @PutMapping("/{ubicacionId}")
    @PreAuthorize("hasAuthority('LOCATION_UPDATE')")
    @Operation(summary = "Actualizar una ubicación", description = "Actualiza datos descriptivos sin cambiar el tipo ni la jerarquía.")
    public ApiResponse<UbicacionResponseDTO> actualizar(
            @PathVariable Long ubicacionId,
            @Valid @RequestBody ActualizarUbicacionRequestDTO solicitud
    ) {
        return ApiResponse.success("Ubicación actualizada correctamente", ubicacionService.actualizar(ubicacionId, solicitud));
    }

    @PatchMapping("/{ubicacionId}/activar")
    @PreAuthorize("hasAuthority('LOCATION_UPDATE')")
    @Operation(summary = "Activar una ubicación")
    public ApiResponse<UbicacionResponseDTO> activar(@PathVariable Long ubicacionId) {
        return ApiResponse.success("Ubicación activada correctamente", ubicacionService.cambiarEstado(ubicacionId, true));
    }

    @PatchMapping("/{ubicacionId}/desactivar")
    @PreAuthorize("hasAuthority('LOCATION_UPDATE')")
    @Operation(summary = "Desactivar una ubicación", description = "No permite desactivar ubicaciones con hijos o stock.")
    public ApiResponse<UbicacionResponseDTO> desactivar(@PathVariable Long ubicacionId) {
        return ApiResponse.success("Ubicación desactivada correctamente", ubicacionService.cambiarEstado(ubicacionId, false));
    }

    @DeleteMapping("/{ubicacionId}")
    @PreAuthorize("hasAuthority('LOCATION_DELETE')")
    @Operation(summary = "Eliminar una ubicación", description = "Solo elimina ubicaciones sin hijos y sin existencias.")
    public ApiResponse<Void> eliminar(@PathVariable Long ubicacionId) {
        ubicacionService.eliminar(ubicacionId);
        return ApiResponse.success("Ubicación eliminada correctamente");
    }
}
