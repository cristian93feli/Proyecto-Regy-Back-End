package com.regyinventory.enums;

public enum RoleName {

    ROLE_ADMIN,
    ROLE_ALMACEN,
    ROLE_AUDITOR,
    ROLE_CONSULTA

}