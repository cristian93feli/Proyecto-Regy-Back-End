package com.regyinventory.enums;

public enum PermissionName {

    USER_CREATE,
    USER_READ,
    USER_UPDATE,
    USER_DELETE,

    ROLE_CREATE,
    ROLE_READ,
    ROLE_UPDATE,
    ROLE_DELETE,

    PRODUCT_CREATE,
    PRODUCT_READ,
    PRODUCT_UPDATE,
    PRODUCT_DELETE,

    CATEGORY_CREATE,
    CATEGORY_READ,
    CATEGORY_UPDATE,
    CATEGORY_DELETE,

    INVENTORY_READ,
    INVENTORY_UPDATE,

    MOVEMENT_CREATE,
    MOVEMENT_READ,

    REPORT_READ

}