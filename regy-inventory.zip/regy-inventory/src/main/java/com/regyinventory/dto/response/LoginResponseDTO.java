package com.regyinventory.dto.response;

import lombok.Builder;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
@Builder
public class LoginResponseDTO {

    private Long id;

    private String username;

    private String nombreCompleto;

    private String token;

}